<?php

use App\ProductType;
use Illuminate\Support\Facades\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Validator;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/','HomeController@mainProduct');
Route::get('/homePage{type}','HomeController@searchByType');

Route::get('/login','AuthController@loginPage');
Route::post('/login','AuthController@login');

Route::get('/homePage','HomeController@search');

Route::get('/register','AuthController@registerPage');
Route::post('/register','AuthController@register');

Route::get('/logout','AuthController@logout');

Route::get('/detail{id}','ProductController@detail');

Route::get('/edit{id}','ProductController@edit');

Route::post('/edit{id}', 'ProductController@update');
Route::get('/remove{id}','ProductController@delete');

Route::get('/add', 'ProductController@add');
Route::post('/add','ProductController@addData');

Route::get('/statTypes', 'ProductTypeController@editPage');

Route::get('/deleteProdTypes{id}', 'ProductTypeController@deleteProdTypes');
Route::POST('statTypes{id}', 'ProductTypeController@updates');

Route::get('/addProductTypes','ProductTypeController@addTypePage');
Route::post('/addProductTypes','ProductTypeController@increaseProductType');


Route::post('/detail{id}', 'ProductController@erganzToCartss');
Route::get('/shopping_cart{id}', 'CartController@shopping_cart');

Route::get('/update_cart{id}','CartController@cartEditPage');
Route::post('/update_cart{id}', 'CartController@bearbeiten_cart');
Route::get('/lösen{id}','CartController@lösen');

Route::get('/addToTransaction{id}','CartController@transaction_add');

Route::get('/transaction_history{id}', 'TransactionController@transaction_page');


