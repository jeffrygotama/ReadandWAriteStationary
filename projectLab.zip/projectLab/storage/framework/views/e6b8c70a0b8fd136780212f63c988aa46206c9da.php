
<?php $__env->startSection('contents'); ?>
    <div class="bg-extra">
        <div class="container">
            <div class="row">
                <?php if($need['authConfirm']): ?>
                    <?php if(Illuminate\Support\Facades\Auth::user()->roles_id == 1): ?>
                        <a class="btn btn-primary my-2 mx-3 p-2" href="<?php echo e(url('/add')); ?>">Add New Stationary</a>
                        <a class="btn btn-primary my-2 mx-3 p-2" href="<?php echo e(url('/addProductTypes')); ?>">Add New Stationary Type</a>
                        <a class="btn btn-primary my-2 mx-3 p-2" href="<?php echo e(url('/statTypes')); ?>">Edit Stationary Type</a>
                    <?php endif; ?>
                <?php endif; ?>

            </div>
            <div class="row">
                <?php if(count($need['products']) > 0): ?>
                <?php $__currentLoopData = $need['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card text-white bg-dark mb-3" style="width: 18rem;">
                    <?php if(!Illuminate\Support\Facades\Auth::user()): ?>
                        <img class="card-img-top image" src="<?php echo e(asset('images/'.$product->image)); ?>" alt="No image" style="height:250px">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($product->name); ?></h5>
                            <h5 class="card-details"><?php echo e($product->description); ?></h5>
                        </div>
                    <?php else: ?>
                    <a href="<?php echo e(url('/detail'.$product->id)); ?>">
                        <img class="card-img-top image" src="<?php echo e(asset('images/'.$product->image)); ?>" alt="No image" style="height:250px">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($product->name); ?></h5>
                            <h5 class="card-details"><?php echo e($product->description); ?></h5>
                        </div>
                    </a>
                    <?php endif; ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <?php else: ?>
                <h5 class="card-title">There's no product match with the keyword</h5>
                <?php endif; ?>
            </div>
            <?php echo e($need['products']->withQueryString()->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jeffr\Downloads\Web Programming\New folder (3)\projectLab\resources\views/homePage.blade.php ENDPATH**/ ?>