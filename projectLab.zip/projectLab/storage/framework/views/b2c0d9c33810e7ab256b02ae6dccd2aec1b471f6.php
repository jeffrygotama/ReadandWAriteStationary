

<?php $__env->startSection('contents'); ?>
<div class="bg-info">
    <div class="container">
        <br>
        <div class="row">
            <div class="col md-5">
                <table style="width=100%" class="table table-bordered table-dark text-center">
                    <thead>
                        <tr>
                            <th scope="col">Number</th>
                            <th scope="col">Stationary Type Name</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($errors->any()): ?>
                            <ul id="errors">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li style="color: red;"><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>   
                        <?php endif; ?>

                        <?php if($message = Session::get('success')): ?>
                            <div class="alert alert-success">
                                <p style="color: blue;"><?php echo e($message); ?></p>
                            </div>
                        <?php endif; ?>

                        <?php $__currentLoopData = $productTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($item->id); ?></th>
                                <td><?php echo e($item->name); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <form method="POST" action="<?php echo e(url('/addProductTypes')); ?>" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="col md-5">
                    <div class="mx-5">
                        <div class="btn btn-primary btn-sm">
                            <span>Choose file</span>
                            
                            <div class="custom-file">
                                <input type="file" name="file_image" value="Choose File" id="file">
                            </div>
                            
                        </div>
                    </div>
                
                    <br>
                
                    <div>
                        <input type="text" class="col-5 p-2 ml-5" name="name" placeholder="Stationary Type" value="<?php echo e(old('name')); ?>">
                    </div>
                    <br>
                    <div>
                        
                        <input type="submit" class="btn btn-primary col-5 ml-5" style="margin: 8px" value="Add New Stationary Type">
                    </div>
                </div>
            </form>
            
        </div>
    </div>
    <br><br><br>
    <div class="d-flex justify-content-center my-5">
        <img src="images/book_timeline.png" alt="Books" class="img-fluid w-50">
    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jeffr\Downloads\Web Programming\New folder (3)\projectLab\resources\views/addProductTypes.blade.php ENDPATH**/ ?>