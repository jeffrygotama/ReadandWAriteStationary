

<?php $__env->startSection('contents'); ?>
<div class="bg-info">
    <br>
    <br>
    <div class="container justify-content-center">
        <?php if(sizeof($transactions) > 0): ?>
            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <table class="table table-dark">
                    <thead>
                        <tr>
                            <th scope="col"><?php echo e($item->created_at); ?></th>
                            <th scope="col">Total: Rp <?php echo e($item->total); ?>,00</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $item->detailTransaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>Product: <?php echo e($detail->product->name); ?></td>
                                <td>Price: Rp. <?php echo e($detail->product->price); ?>,00</td>
                                <td>Quantity: <?php echo e($detail->quantity); ?></td>
                                <td>Sub Total: <?php echo e($detail->subtotal); ?> </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <h4>You don't have any Transaction</h4>
        <?php endif; ?>
        <div class="d-flex justify-content-center my-5">
            <img src="images/book_timeline.png" alt="Books" class="img-fluid w-50">
        </div>
        <br>
    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jeffr\Downloads\Web Programming\New folder (3)\projectLab\resources\views//transaction_history.blade.php ENDPATH**/ ?>