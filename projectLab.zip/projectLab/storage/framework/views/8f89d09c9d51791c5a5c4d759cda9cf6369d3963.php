<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
        <title>Welcome</title>
    </head>
    <body>
        <header>
            <div class="d-flex justify-content-end align-content-center mt-3 mr-3">
            <?php if($auth == 0): ?>
                <a class="btn btn-primary m-2" href="<?php echo e(url('/login')); ?>">Login</a>
                <a class="btn btn-primary m-2" href="<?php echo e(url('/register')); ?>">Register</a>                
            <?php else: ?>
                <a class="btn btn-primary m-2" href="<?php echo e(url('/logout')); ?>">Logout</a>
            <?php endif; ?>
            </div>
        </header>
        <div class="container">
                <h1 class="my-5 text-center" style="font-size: 100px"><a href="/">ReadAndWArite</a></h1>
                <form method="GET" action="<?php echo e(url('/homePage')); ?>" class="search-form">
                <div class="d-flex justify-content-center col-md-12">
                    <input class="col-8" style="padding: 10px" type="text" placeholder="Search for stationary" name="search" value="<?php echo e(Request::input('search')); ?>">
                </div>
                    <div class="d-flex justify-content-center col-md-12">
                        <input type="submit" class="btn btn-primary my-3 d-flex justify-content-center text-center" style="padding: 8px 15px 8px 15px" value="Search">
                    </div>
                </form>
                <div class="d-flex align-content-start row my-5">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3 p-2">
                            <a href="<?php echo e(url('/homePage'.$p->id)); ?>">
                                <img src="<?php echo e(asset('images/'.$p->image)); ?>" alt="Subject Notebook" class="img-thumbnail" style="width:250px;height:250px">
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
        </div>
    
    </body>
</html>
<?php /**PATH C:\Users\jeffr\Downloads\Web Programming\New folder (3)\projectLab\resources\views/welcome.blade.php ENDPATH**/ ?>