


<?php $__env->startSection('contents'); ?>
<div class="bg-info">
    <div class="container">
        <br>
        <div class="bg-light">
            <div class="m-3">
                <br>
                <?php if($message = Session::get('success_add_transaction')): ?>
                            <div class="alert alert-success">
                                <p style="color: blue;"><?php echo e($message); ?></p>
                            </div>
                <?php endif; ?>
                <?php if(sizeof($allCarts) < 1): ?>
                    <h4>Do Some Transaction to see your products in cart</h4>
                <?php else: ?>
                    <?php $__currentLoopData = $allCarts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h4>Stationary Name: <?php echo e($item->products->name); ?></h4>
                            <ul>
                                <li>Stationary Price: <?php echo e($item->products->price); ?></li>
                                <li>Quantity: <?php echo e($item->quantity); ?></li>
                            </ul>
                        <br>
                        <h4>Total: Rp. <?php echo e($item->total); ?>,00</h4>
                            <div class="d-flex justify-content-end align-content-center mt-3 mr-2">
                                <form action="" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <a href="<?php echo e(url('/update_cart'.$item->id)); ?>" class="btn btn-primary">Edit Item</a>
                                    <a href="<?php echo e(url('/lösen'.$item->id)); ?>" class="btn btn-danger">Delete Item</a>
                                </form>
                            </div>
                        <hr>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($message = Session::get('success')): ?>
                            <div class="alert alert-success">
                                <p style="color: blue;"><?php echo e($message); ?></p>
                            </div>
                        <?php endif; ?>
                        <a class="btn btn-danger m-2 p-3" href="<?php echo e(url('/addToTransaction'.Illuminate\Support\Facades\Auth::user()->id)); ?>">CheckOut</a>             
                <?php endif; ?>
            </div>
            <br>
        </div>
        <br><br><br>
        <div class="d-flex justify-content-center my-5">
            <img src="images/book_timeline.png" alt="Books" class="img-fluid w-50">
        </div>
    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jeffr\Downloads\Web Programming\New folder (3)\projectLab\resources\views//shopping_cart.blade.php ENDPATH**/ ?>