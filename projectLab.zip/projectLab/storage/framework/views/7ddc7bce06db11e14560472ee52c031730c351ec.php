

<?php $__env->startSection('contents'); ?>
<div class="bg-info">
    <div class="container">
        <br><br>
        <form method="POST" action="<?php echo e(url('/add')); ?>" class="ml-5" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <?php if($errors->any()): ?>
            <ul id="errors">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li style="color: red;"><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>   
        <?php endif; ?>

        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p style="color: blue;"><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>
        <div class="row">
            <div class="d-flex justify-content-center">
                <div class="mx-2">
                    <div class="custom-file">
                        <input type="file" name="file_image" class="form-control" value="Choose File" id="file">
                    </div>
                </div>
            </div>
        </div>
        <br>
            
            <div>
                <input type="text" class="col-5 p-2" name="name" placeholder="Name" value="<?php echo e(old('name')); ?>" required>
            </div>
            <br>
            <div>
                <input type="text" class="col-5 p-2" name="description" placeholder="Description" value="<?php echo e(old('description')); ?>" required>
            </div>
            <br>
            <div class="row">
                <a class="btn btn-light ml-3">Types</a>
                <select name="stationary_type" id="type" class="col-4 p-2">
                    <option value="">Select Type</option>
                    <?php $__currentLoopData = $product_typess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
            </div>
            <br>
            <div>
                <input type="number" class="col-5 p-2" name="stock" placeholder="Stock" value="<?php echo e(old('stock')); ?>" required>
            </div>
            <br>
            <div>
                <input type="number" class="col-5 p-2" name="price" placeholder="Price" value="<?php echo e(old('price')); ?>" required>
            </div>
            <br>
            <input type="submit" class="btn btn-primary col-2 p-2" style="margin: 8px" value="Add Stationary Data">
        </form>
        <br><br><br>
        <div class="d-flex justify-content-center my-5">
            <img src="images/book_timeline.png" alt="Books" class="img-fluid w-50">
        </div>
    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jeffr\Downloads\Web Programming\New folder (3)\projectLab\resources\views//add.blade.php ENDPATH**/ ?>