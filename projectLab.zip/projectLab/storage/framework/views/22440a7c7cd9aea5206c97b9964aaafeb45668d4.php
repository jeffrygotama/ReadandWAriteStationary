

<?php $__env->startSection('contents'); ?>
<div class="bg-info">
    <br><br>
    <div class="container bg-light card-header my-2">
        <?php if($errors->any()): ?>
            <ul id="errors">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li style="color: red;"><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>   
        <?php endif; ?>

        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p style="color: blue;"><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>
        <br>
        <form method="POST" action="<?php echo e(url('/edit'.$product->id)); ?>" class="ml-5">
            <?php echo e(csrf_field()); ?>

            <div>
                <input type="text" class="col-5 p-2" name="name" value="<?php echo e($product->name); ?>">
            </div>
            <br>
            <div>
                <input type="number" class="col-5 p-2" name="stock" placeholder="Stock" value="<?php echo e($product->stock); ?>">
            </div>
            <br>
            <div>
                <input type="number" class="col-5 p-2" name="price" placeholder="Price" value="<?php echo e($product->price); ?>">
            </div>
            <br>
            <div>
                <input type="text" class="col-5 p-2" name="description" placeholder="Description" value="<?php echo e($product->description); ?>">
            </div>
            <br>
            <input type="submit" class="btn btn-primary col-2 p-2" style="margin: 8px" value="Update Stationary Data">
        </form>
        <br><br><br>
    </div>
    <div class="d-flex justify-content-center my-5">
        <img src="images/book_timeline.png" alt="Books" class="img-fluid w-50">
    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jeffr\Downloads\Web Programming\New folder (3)\projectLab\resources\views/edit.blade.php ENDPATH**/ ?>