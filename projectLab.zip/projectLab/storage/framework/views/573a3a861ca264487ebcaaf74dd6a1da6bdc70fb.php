

<?php $__env->startSection('contents'); ?>
<div class="bg-info">
    <div class="container">
        <br>
        <div class="bg-light">
            <br>
            <div class="row m-3">
                <div class="col-md-3">
                    <img src="<?php echo e(asset('images/'.$prodCart->products->image)); ?>" class="img-thumbnail">
                </div>
                <div class="col-md-4 ml-5">
                    <h3>Stationary Name: <?php echo e($prodCart->products->name); ?></h3>
                    <h3>Stationary Price: <?php echo e($prodCart->products->price); ?></h3>
                    <h3>Quantity: <?php echo e($prodCart->quantity); ?></h3>
                    <h3>Summary Type: <?php echo e($prodCart->products->product_type->name); ?></h3>
                    <h3>Description: <?php echo e($prodCart->products->description); ?></h3>
                </div>
                <div class="col-md-3 ml-5">
                    <br><br><br><br><br>
                    <br><br><br><br><br>
                    <br><br><br>
                    <form action="<?php echo e(url('/update_cart'.$prodCart->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-inline my-2 my-lg-0">
                            <input class="form-control mr-1" type="number" placeholder="Quantity" name="quantity" id="quantity">
                            <input type="submit" class="btn btn-primary my-2 my-sm-0" value="Update Cart">
                        </div>
                        <?php if($errors->any()): ?>
                        <ul id="errors">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li style="color: red;"><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>   
                        <?php endif; ?>

                        <?php if($message = Session::get('success')): ?>
                            <div class="alert alert-success">
                                <p style="color: blue;"><?php echo e($message); ?></p>
                            </div>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
            <br>
        </div>
        <div class="d-flex justify-content-center my-5">
            <img src="images/book_timeline.png" alt="Books" class="img-fluid w-50">
        </div>
        <br>
    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jeffr\Downloads\Web Programming\New folder (3)\projectLab\resources\views//update_cart.blade.php ENDPATH**/ ?>