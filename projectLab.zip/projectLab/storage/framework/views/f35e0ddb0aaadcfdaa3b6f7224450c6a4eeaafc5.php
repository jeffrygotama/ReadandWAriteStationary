<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <title>Home Page</title>
</head>
<body>
    <header>
        <div class="d-flex justify-content-center mt-3">
            <h4 class="m-1 font-weight-bold" style="font-size: 36px"><a href="<?php echo e(url('/')); ?>">ReadandWArite</a></h4>
            <form method="GET" action="<?php echo e(url('/homePage')); ?>" class="search-form">
                <input class="col-8" style="width:400px;" type="text" placeholder="Search" name="search" value="<?php echo e(Request::input('search')); ?>">
                <input type="submit" class="btn btn-primary m-2"value="Search">
            </form>
            <div class="mx-5">
                <select class="form-control" name="select1" id="select1">
                <?php if($need['authConfirm'] == 0 && !Illuminate\Support\Facades\Auth::user()): ?>
                    <?php $__currentLoopData = $need['roles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($i->name == 'Guest'): ?>
                            <option value=""><?php echo e($i->name); ?></option>
                        <?php else: ?>
                            continue;
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php $__currentLoopData = $need['roles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($i->name == 'Guest'): ?>
                            continue
                        <?php else: ?>
                            <option value=""><?php echo e($i->name); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <?php if($need['authConfirm'] == 1): ?>
                        <?php $__currentLoopData = $need['roles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(Illuminate\Support\Facades\Auth::user()->roles_id == $item->id): ?>
                                <option value=""><?php echo e($item->name); ?></option>         
                            <?php else: ?>
                                <?php continue; ?>
                            <?php endif; ?>
                    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $need['roles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(Illuminate\Support\Facades\Auth::user()->roles_id == $item->id): ?>
                                    <?php continue; ?>
                                <?php else: ?>
                                    <option value=""><?php echo e($item->name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endif; ?>
                </select>
            </div>
            <?php if(!Illuminate\Support\Facades\Auth::user()): ?>
                <a class="btn btn-primary m-2" href="<?php echo e(url('/login')); ?>">Login</a>
                <a class="btn btn-primary m-2" href="<?php echo e(url('/register')); ?>">Register</a>
            <?php endif; ?>

            <?php if($need['authConfirm']): ?>
                <?php if(Illuminate\Support\Facades\Auth::user()->roles_id == 2): ?>
                    <a class="btn btn-primary my-2 mx-3 p-2" href="<?php echo e(url('/shopping_cart'.Illuminate\Support\Facades\Auth::user()->id)); ?>">Cart</a>
                    <a class="btn btn-primary my-2 mx-3 p-2" href="<?php echo e(url('/transaction_history'.Illuminate\Support\Facades\Auth::user()->id)); ?>">History</a>
                <?php endif; ?>
            <?php endif; ?>
            <?php if($need['authConfirm'] == 1): ?>
                <a class="btn btn-primary my-2 mx-3 p-2" href="<?php echo e(url('logout')); ?>">Logout</a>
            <?php endif; ?>
        </div>
    </header>
    <br>
    <?php echo $__env->yieldContent('contents'); ?>
</body>
</html><?php /**PATH C:\Users\jeffr\Downloads\Web Programming\New folder (3)\projectLab\resources\views/home.blade.php ENDPATH**/ ?>