

<?php $__env->startSection('contents'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card bg-light">
                <div class="card-body">
                    <div class="container">
                        <div class="row">
                            <div class="col col-sm">
                                <img class="card-img-top image" src="<?php echo e(asset('images/'.$product->image)); ?>" alt="" style="width: 400px; height:400px;">
                            </div>
                            <div class="col col-sm">
                                <h3>Stationary Name: <?php echo e($product->name); ?></h3>
                                <h3>Stationary Price: <?php echo e($product->price); ?></h3>
                                <h3>Stationary Stock: <?php echo e($product->stock); ?></h3>
                                <h3>Stationary Type: <?php echo e($product->product_type->name); ?></h3>
                                <h3>Description: <?php echo e($product->description); ?></h3>
                                <?php if(Auth::user()->roles_id == 1): ?>
                                    <form action="" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        
                                        <a href="<?php echo e(url('/remove'.$product->id)); ?>" class="btn btn-danger">delete</a>
                                        <a href="<?php echo e(url('/edit'.$product->id)); ?>" class="btn btn-primary">edit</a>
                                    </form>

                                <?php elseif(Auth::user()->roles_id == 2): ?>
                                    <form action="<?php echo e(url('/detail'.$product->id)); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <div class="form-inline my-2 my-lg-0">
                                            <input class="form-control mr-1" type="number" placeholder="Quantity" name="quantity" id="quantity">
                                            <input type="submit" class="btn btn-primary my-2 my-sm-0" value="Add to Cart">
                                        </div>
                                    </form>
                                <?php endif; ?>
                                <?php if($errors->any()): ?>
                                    <ul id="errors">
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li style="color: red;"><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>   
                                <?php endif; ?>

                                <?php if($message = Session::get('success')): ?>
                                    <div class="alert alert-success">
                                        <p style="color: blue;"><?php echo e($message); ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
              </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jeffr\Downloads\Web Programming\New folder (3)\projectLab\resources\views/detail.blade.php ENDPATH**/ ?>