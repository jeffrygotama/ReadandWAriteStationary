

<?php $__env->startSection('contents'); ?>
<div class="bg-info">
    <div class="container">
        <br>
        <div>
            <table style="width=100%" class="table table-bordered table-dark text-center">
                <thead>
                    <tr>
                        <th scope="col">Number</th>
                        <th scope="col">Stationary Type Name</th>
                        <th scope="col">Admin</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($errors->any()): ?>
                        <ul id="errors">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li style="color: red;"><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>   
                    <?php endif; ?>

                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <p style="color: blue;"><?php echo e($message); ?></p>
                        </div>
                    <?php endif; ?>
                    <?php $__currentLoopData = $productTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($item->id); ?></th>
                        <td><?php echo e($item->name); ?></td>
                        <td scope="row">
                            <form action="<?php echo e(url('/statTypes'.$item->id)); ?>" method="POST">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group col-12 d-flex m-0 pr-2">
                                    <input class="col-5 p-2" type="text" placeholder="Name" name="name">
                                    
                                    <input type="submit" class="btn btn-primary" value="update">
                                    <a href="<?php echo e(url('/deleteProdTypes'.$item->id)); ?>" class="btn btn-danger">Delete</a>
                                </div>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <br><br><br>
    <div class="d-flex justify-content-center my-5">
        <img src="images/book_timeline.png" alt="Books" class="img-fluid w-50">
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jeffr\Downloads\Web Programming\New folder (3)\projectLab\resources\views/statTypes.blade.php ENDPATH**/ ?>