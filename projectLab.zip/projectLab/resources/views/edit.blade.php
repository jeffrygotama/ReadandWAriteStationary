@extends('home')

@section('contents')
<div class="bg-info">
    <br><br>
    <div class="container bg-light card-header my-2">
        @if ($errors->any())
            <ul id="errors">
                @foreach ($errors->all() as $error)
            <li style="color: red;">{{$error}}</li>
                @endforeach
            </ul>   
        @endif

        @if ($message = Session::get('success'))
            <div class="alert alert-success">
                <p style="color: blue;">{{ $message }}</p>
            </div>
        @endif
        <br>
        <form method="POST" action="{{url('/edit'.$product->id)}}" class="ml-5">
            {{ csrf_field() }}
            <div>
                <input type="text" class="col-5 p-2" name="name" value="{{$product->name}}">
            </div>
            <br>
            <div>
                <input type="number" class="col-5 p-2" name="stock" placeholder="Stock" value="{{$product->stock}}">
            </div>
            <br>
            <div>
                <input type="number" class="col-5 p-2" name="price" placeholder="Price" value="{{$product->price}}">
            </div>
            <br>
            <div>
                <input type="text" class="col-5 p-2" name="description" placeholder="Description" value="{{$product->description}}">
            </div>
            <br>
            <input type="submit" class="btn btn-primary col-2 p-2" style="margin: 8px" value="Update Stationary Data">
        </form>
        <br><br><br>
    </div>
    <div class="d-flex justify-content-center my-5">
        <img src="images/book_timeline.png" alt="Books" class="img-fluid w-50">
    </div>
</div>
    
@endsection