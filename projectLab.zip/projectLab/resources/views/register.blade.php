<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="{{asset('css/app.css')}}">
    <script src="{{asset('js/app.js')}}"></script>
    <title>Register</title>
</head>
<body>
    <header>
        <div class="d-flex justify-content-center mt-3">
            <h4 class="m-1 font-weight-bold" style="font-size: 36px"><a href="{{url('/')}}">ReadandWArite</a></h4>
                <form method="GET" action="{{url('/homePage')}}" class="search-form">
                    <input type="text" class="col-8" style="width:400px;" name="search" value="{{Request::input('search')}}">
                    <input type="submit" class="btn btn-primary m-2"value="Search">
                </form>
            <a class="btn btn-primary m-2 ml-5" href="{{url('/login')}}">Login</a>
            <a class="btn btn-primary m-2" href="{{url('/register')}}">Register</a>
        </div>
    </header>
    <br>
    <div class="bg-info">
        <br><br>
        <div class="container bg-light card-header my-2">
            <h2 class="m-2">Register</h2>
            <hr>
            @if ($errors->any())
                <ul id="errors">
                    @foreach ($errors->all() as $error)
                <li style="color: red;">{{$error}}</li>
                    @endforeach
                </ul>   
            @endif

            @if ($message = Session::get('success'))
                <div class="alert alert-success">
                    <p style="color: blue;">{{ $message }}</p>
                </div>
            @endif
            <form method="POST" action="{{url('/register')}}" class="ml-5">
                {{ csrf_field() }}
                <div>
                    <label for="name" class="col-2">Name</label> 
                    <input type="text" class="col-4" name="name" value="{{old('name')}}" required>
                </div>
                <br>
                <div>
                    <label for="email" class="col-2">Email Address</label> 
                    <input type="email" class="col-4" name="email" value="{{old('email')}}" required>
                </div>
                
                <br>
                <div>
                    <label for="password" class="col-2">Password</label> 
                    <input type="password" class="col-4" name="password" value="{{old('password')}}" required>
                </div>
                
                <br>
                <div>
                    <label for="conf_password" class="col-2">Confirm Password</label>  
                    <input type="password" class="col-4" name="confirm_password" value="{{old('confirm_password')}}" required>
                </div>
                <br>
                <input type="submit" class="btn btn-primary col-1" style="margin: 6px 17%" value="register">
            </form>
            <br><br><br>
        </div>
        <div class="d-flex justify-content-center my-5">
            <img src="images/book_timeline.png" alt="Books" class="img-fluid w-50">
        </div>
    </div>
</body>
</html>