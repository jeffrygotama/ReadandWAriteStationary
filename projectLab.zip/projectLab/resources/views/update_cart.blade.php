@extends('home')

@section('contents')
<div class="bg-info">
    <div class="container">
        <br>
        <div class="bg-light">
            <br>
            <div class="row m-3">
                <div class="col-md-3">
                    <img src="{{asset('images/'.$prodCart->products->image)}}" class="img-thumbnail">
                </div>
                <div class="col-md-4 ml-5">
                    <h3>Stationary Name: {{$prodCart->products->name}}</h3>
                    <h3>Stationary Price: {{$prodCart->products->price}}</h3>
                    <h3>Quantity: {{$prodCart->quantity}}</h3>
                    <h3>Summary Type: {{$prodCart->products->product_type->name}}</h3>
                    <h3>Description: {{$prodCart->products->description}}</h3>
                </div>
                <div class="col-md-3 ml-5">
                    <br><br><br><br><br>
                    <br><br><br><br><br>
                    <br><br><br>
                    <form action="{{url('/update_cart'.$prodCart->id)}}" method="POST" enctype="multipart/form-data">
                        {{ csrf_field() }}
                        <div class="form-inline my-2 my-lg-0">
                            <input class="form-control mr-1" type="number" placeholder="Quantity" name="quantity" id="quantity">
                            <input type="submit" class="btn btn-primary my-2 my-sm-0" value="Update Cart">
                        </div>
                        @if ($errors->any())
                        <ul id="errors">
                            @foreach ($errors->all() as $error)
                        <li style="color: red;">{{$error}}</li>
                            @endforeach
                        </ul>   
                        @endif

                        @if ($message = Session::get('success'))
                            <div class="alert alert-success">
                                <p style="color: blue;">{{ $message }}</p>
                            </div>
                        @endif
                    </form>
                </div>
            </div>
            <br>
        </div>
        <div class="d-flex justify-content-center my-5">
            <img src="images/book_timeline.png" alt="Books" class="img-fluid w-50">
        </div>
        <br>
    </div>
</div>
    
@endsection