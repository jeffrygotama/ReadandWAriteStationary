@extends('home')

@section('contents')
<div class="bg-info">
    <br>
    <br>
    <div class="container justify-content-center">
        @if (sizeof($transactions) > 0)
            @foreach ($transactions as $item)
                <table class="table table-dark">
                    <thead>
                        <tr>
                            <th scope="col">{{$item->created_at}}</th>
                            <th scope="col">Total: Rp {{$item->total}},00</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($item->detailTransaction as $detail)
                            <tr>
                                <td>Product: {{$detail->product->name}}</td>
                                <td>Price: Rp. {{$detail->product->price}},00</td>
                                <td>Quantity: {{$detail->quantity}}</td>
                                <td>Sub Total: {{$detail->subtotal}} </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
                <br>
            @endforeach
        @else
            <h4>You don't have any Transaction</h4>
        @endif
        <div class="d-flex justify-content-center my-5">
            <img src="images/book_timeline.png" alt="Books" class="img-fluid w-50">
        </div>
        <br>
    </div>
</div>
    
@endsection