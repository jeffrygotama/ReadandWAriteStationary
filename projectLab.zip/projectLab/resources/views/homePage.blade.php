@extends('home')
@section('contents')
    <div class="bg-extra">
        <div class="container">
            <div class="row">
                @if($need['authConfirm'])
                    @if (Illuminate\Support\Facades\Auth::user()->roles_id == 1)
                        <a class="btn btn-primary my-2 mx-3 p-2" href="{{url('/add')}}">Add New Stationary</a>
                        <a class="btn btn-primary my-2 mx-3 p-2" href="{{url('/addProductTypes')}}">Add New Stationary Type</a>
                        <a class="btn btn-primary my-2 mx-3 p-2" href="{{url('/statTypes')}}">Edit Stationary Type</a>
                    @endif
                @endif

            </div>
            <div class="row">
                @if (count($need['products']) > 0)
                @foreach ($need['products'] as $product)
                <div class="card text-white bg-dark mb-3" style="width: 18rem;">
                    @if (!Illuminate\Support\Facades\Auth::user())
                        <img class="card-img-top image" src="{{asset('images/'.$product->image)}}" alt="No image" style="height:250px">
                        <div class="card-body">
                            <h5 class="card-title">{{$product->name}}</h5>
                            <h5 class="card-details">{{$product->description}}</h5>
                        </div>
                    @else
                    <a href="{{ url('/detail'.$product->id)}}">
                        <img class="card-img-top image" src="{{asset('images/'.$product->image)}}" alt="No image" style="height:250px">
                        <div class="card-body">
                            <h5 class="card-title">{{$product->name}}</h5>
                            <h5 class="card-details">{{$product->description}}</h5>
                        </div>
                    </a>
                    @endif
                </div>
                @endforeach
                
                @else
                <h5 class="card-title">There's no product match with the keyword</h5>
                @endif
            </div>
            {{$need['products']->withQueryString()->links()}}
        </div>
    </div>
@endsection