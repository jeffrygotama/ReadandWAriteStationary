@extends('home')

@section('contents')
<div class="bg-info">
    <div class="container">
        <br><br>
        <form method="POST" action="{{url('/add')}}" class="ml-5" enctype="multipart/form-data">
        {{ csrf_field() }}
        @if ($errors->any())
            <ul id="errors">
                @foreach ($errors->all() as $error)
            <li style="color: red;">{{$error}}</li>
                @endforeach
            </ul>   
        @endif

        @if ($message = Session::get('success'))
            <div class="alert alert-success">
                <p style="color: blue;">{{ $message }}</p>
            </div>
        @endif
        <div class="row">
            <div class="d-flex justify-content-center">
                <div class="mx-2">
                    <div class="custom-file">
                        <input type="file" name="file_image" class="form-control" value="Choose File" id="file">
                    </div>
                </div>
            </div>
        </div>
        <br>
            
            <div>
                <input type="text" class="col-5 p-2" name="name" placeholder="Name" value="{{old('name')}}" required>
            </div>
            <br>
            <div>
                <input type="text" class="col-5 p-2" name="description" placeholder="Description" value="{{old('description')}}" required>
            </div>
            <br>
            <div class="row">
                <a class="btn btn-light ml-3">Types</a>
                <select name="stationary_type" id="type" class="col-4 p-2">
                    <option value="">Select Type</option>
                    @foreach ($product_typess as $item)
                    <option value="{{$item->id}}">{{$item->name}}</option>
                    @endforeach
                  </select>
            </div>
            <br>
            <div>
                <input type="number" class="col-5 p-2" name="stock" placeholder="Stock" value="{{old('stock')}}" required>
            </div>
            <br>
            <div>
                <input type="number" class="col-5 p-2" name="price" placeholder="Price" value="{{old('price')}}" required>
            </div>
            <br>
            <input type="submit" class="btn btn-primary col-2 p-2" style="margin: 8px" value="Add Stationary Data">
        </form>
        <br><br><br>
        <div class="d-flex justify-content-center my-5">
            <img src="images/book_timeline.png" alt="Books" class="img-fluid w-50">
        </div>
    </div>
</div>
    
@endsection