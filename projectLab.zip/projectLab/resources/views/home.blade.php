<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="{{asset('css/app.css')}}">
    <script src="{{asset('js/app.js')}}"></script>
    <title>Home Page</title>
</head>
<body>
    <header>
        <div class="d-flex justify-content-center mt-3">
            <h4 class="m-1 font-weight-bold" style="font-size: 36px"><a href="{{url('/')}}">ReadandWArite</a></h4>
            <form method="GET" action="{{url('/homePage')}}" class="search-form">
                <input class="col-8" style="width:400px;" type="text" placeholder="Search" name="search" value="{{Request::input('search')}}">
                <input type="submit" class="btn btn-primary m-2"value="Search">
            </form>
            <div class="mx-5">
                <select class="form-control" name="select1" id="select1">
                @if ($need['authConfirm'] == 0 && !Illuminate\Support\Facades\Auth::user())
                    @foreach ($need['roles'] as $i)
                        @if ($i->name == 'Guest')
                            <option value="">{{$i->name}}</option>
                        @else
                            continue;
                        @endif
                    @endforeach

                    @foreach ($need['roles'] as $i)
                        @if ($i->name == 'Guest')
                            continue
                        @else
                            <option value="">{{$i->name}}</option>
                        @endif
                    @endforeach
                @else
                    @if($need['authConfirm'] == 1)
                        @foreach ($need['roles'] as $item)
                            @if(Illuminate\Support\Facades\Auth::user()->roles_id == $item->id)
                                <option value="">{{$item->name}}</option>         
                            @else
                                @continue
                            @endif
                    
                        @endforeach
                            @foreach ($need['roles'] as $item)
                                @if(Illuminate\Support\Facades\Auth::user()->roles_id == $item->id)
                                    @continue
                                @else
                                    <option value="">{{$item->name}}</option>
                                @endif
                            @endforeach
                    @endif
                @endif
                </select>
            </div>
            @if(!Illuminate\Support\Facades\Auth::user())
                <a class="btn btn-primary m-2" href="{{url('/login')}}">Login</a>
                <a class="btn btn-primary m-2" href="{{url('/register')}}">Register</a>
            @endif

            @if ($need['authConfirm'])
                @if(Illuminate\Support\Facades\Auth::user()->roles_id == 2)
                    <a class="btn btn-primary my-2 mx-3 p-2" href="{{url('/shopping_cart'.Illuminate\Support\Facades\Auth::user()->id)}}">Cart</a>
                    <a class="btn btn-primary my-2 mx-3 p-2" href="{{url('/transaction_history'.Illuminate\Support\Facades\Auth::user()->id)}}">History</a>
                @endif
            @endif
            @if($need['authConfirm'] == 1)
                <a class="btn btn-primary my-2 mx-3 p-2" href="{{url('logout')}}">Logout</a>
            @endif
        </div>
    </header>
    <br>
    @yield('contents')
</body>
</html>