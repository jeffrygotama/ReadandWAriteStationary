@extends('home')

@section('contents')
<div class="bg-info">
    <div class="container">
        <br>
        <div class="row">
            <div class="col md-5">
                <table style="width=100%" class="table table-bordered table-dark text-center">
                    <thead>
                        <tr>
                            <th scope="col">Number</th>
                            <th scope="col">Stationary Type Name</th>
                        </tr>
                    </thead>
                    <tbody>
                        @if ($errors->any())
                            <ul id="errors">
                                @foreach ($errors->all() as $error)
                            <li style="color: red;">{{$error}}</li>
                                @endforeach
                            </ul>   
                        @endif

                        @if ($message = Session::get('success'))
                            <div class="alert alert-success">
                                <p style="color: blue;">{{ $message }}</p>
                            </div>
                        @endif

                        @foreach ($productTypes as $item)
                            <tr>
                                <th scope="row">{{$item->id}}</th>
                                <td>{{$item->name}}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <form method="POST" action="{{url('/addProductTypes')}}" enctype="multipart/form-data">
                {{ csrf_field() }}
                <div class="col md-5">
                    <div class="mx-5">
                        <div class="btn btn-primary btn-sm">
                            <span>Choose file</span>
                            {{-- <input type="file" name="files_image" value="choose file"> --}}
                            <div class="custom-file">
                                <input type="file" name="file_image" value="Choose File" id="file">
                            </div>
                            {{-- <input type="file" name="file_image" class="form-control" value="Choose File" id="file"> --}}
                        </div>
                    </div>
                
                    <br>
                
                    <div>
                        <input type="text" class="col-5 p-2 ml-5" name="name" placeholder="Stationary Type" value="{{old('name')}}">
                    </div>
                    <br>
                    <div>
                        {{-- <a class="btn btn-primary col-5 ml-5 " href="" style="margin: 8px">Add New Stationary Type</a> --}}
                        <input type="submit" class="btn btn-primary col-5 ml-5" style="margin: 8px" value="Add New Stationary Type">
                    </div>
                </div>
            </form>
            
        </div>
    </div>
    <br><br><br>
    <div class="d-flex justify-content-center my-5">
        <img src="images/book_timeline.png" alt="Books" class="img-fluid w-50">
    </div>
</div>
    
@endsection