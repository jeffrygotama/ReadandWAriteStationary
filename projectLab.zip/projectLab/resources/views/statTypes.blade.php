@extends('home')

@section('contents')
<div class="bg-info">
    <div class="container">
        <br>
        <div>
            <table style="width=100%" class="table table-bordered table-dark text-center">
                <thead>
                    <tr>
                        <th scope="col">Number</th>
                        <th scope="col">Stationary Type Name</th>
                        <th scope="col">Admin</th>
                    </tr>
                </thead>
                <tbody>
                    @if ($errors->any())
                        <ul id="errors">
                            @foreach ($errors->all() as $error)
                        <li style="color: red;">{{$error}}</li>
                            @endforeach
                        </ul>   
                    @endif

                    @if ($message = Session::get('success'))
                        <div class="alert alert-success">
                            <p style="color: blue;">{{ $message }}</p>
                        </div>
                    @endif
                    @foreach ($productTypes as $item)
                    <tr>
                        <th scope="row">{{$item->id}}</th>
                        <td>{{$item->name}}</td>
                        <td scope="row">
                            <form action="{{url('/statTypes'.$item->id)}}" method="POST">
                                {{ csrf_field() }}
                                <div class="form-group col-12 d-flex m-0 pr-2">
                                    <input class="col-5 p-2" type="text" placeholder="Name" name="name">
                                    {{-- <button class="btn btn-primary my-2 my-sm-0" type="submit">Update</button> --}}
                                    <input type="submit" class="btn btn-primary" value="update">
                                    <a href="{{url('/deleteProdTypes'.$item->id)}}" class="btn btn-danger">Delete</a>
                                </div>
                            </form>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
    <br><br><br>
    <div class="d-flex justify-content-center my-5">
        <img src="images/book_timeline.png" alt="Books" class="img-fluid w-50">
    </div>
</div>
@endsection