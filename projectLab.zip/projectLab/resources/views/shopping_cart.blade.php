@extends('home')


@section('contents')
<div class="bg-info">
    <div class="container">
        <br>
        <div class="bg-light">
            <div class="m-3">
                <br>
                @if ($message = Session::get('success_add_transaction'))
                            <div class="alert alert-success">
                                <p style="color: blue;">{{ $message }}</p>
                            </div>
                @endif
                @if (sizeof($allCarts) < 1)
                    <h4>Do Some Transaction to see your products in cart</h4>
                @else
                    @foreach ($allCarts as $item)
                        <h4>Stationary Name: {{$item->products->name}}</h4>
                            <ul>
                                <li>Stationary Price: {{$item->products->price}}</li>
                                <li>Quantity: {{$item->quantity}}</li>
                            </ul>
                        <br>
                        <h4>Total: Rp. {{$item->total}},00</h4>
                            <div class="d-flex justify-content-end align-content-center mt-3 mr-2">
                                <form action="" method="POST">
                                    {{ csrf_field() }}
                                    <a href="{{url('/update_cart'.$item->id)}}" class="btn btn-primary">Edit Item</a>
                                    <a href="{{url('/lösen'.$item->id)}}" class="btn btn-danger">Delete Item</a>
                                </form>
                            </div>
                        <hr>  
                    @endforeach
                        @if ($message = Session::get('success'))
                            <div class="alert alert-success">
                                <p style="color: blue;">{{ $message }}</p>
                            </div>
                        @endif
                        <a class="btn btn-danger m-2 p-3" href="{{url('/addToTransaction'.Illuminate\Support\Facades\Auth::user()->id)}}">CheckOut</a>             
                @endif
            </div>
            <br>
        </div>
        <br><br><br>
        <div class="d-flex justify-content-center my-5">
            <img src="images/book_timeline.png" alt="Books" class="img-fluid w-50">
        </div>
    </div>
</div>
    
@endsection