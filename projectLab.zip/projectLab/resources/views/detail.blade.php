@extends('home')

@section('contents')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card bg-light">
                <div class="card-body">
                    <div class="container">
                        <div class="row">
                            <div class="col col-sm">
                                <img class="card-img-top image" src="{{asset('images/'.$product->image)}}" alt="" style="width: 400px; height:400px;">
                            </div>
                            <div class="col col-sm">
                                <h3>Stationary Name: {{$product->name}}</h3>
                                <h3>Stationary Price: {{$product->price}}</h3>
                                <h3>Stationary Stock: {{$product->stock}}</h3>
                                <h3>Stationary Type: {{$product->product_type->name}}</h3>
                                <h3>Description: {{$product->description}}</h3>
                                @if(Auth::user()->roles_id == 1)
                                    <form action="" method="POST">
                                        {{ csrf_field() }}
                                        {{-- <button type="submit" class="btn btn-danger">Delete</button> --}}
                                        <a href="{{url('/remove'.$product->id)}}" class="btn btn-danger">delete</a>
                                        <a href="{{url('/edit'.$product->id)}}" class="btn btn-primary">edit</a>
                                    </form>

                                @elseif(Auth::user()->roles_id == 2)
                                    <form action="{{url('/detail'.$product->id)}}" method="POST">
                                        {{ csrf_field() }}
                                        <div class="form-inline my-2 my-lg-0">
                                            <input class="form-control mr-1" type="number" placeholder="Quantity" name="quantity" id="quantity">
                                            <input type="submit" class="btn btn-primary my-2 my-sm-0" value="Add to Cart">
                                        </div>
                                    </form>
                                @endif
                                @if ($errors->any())
                                    <ul id="errors">
                                        @foreach ($errors->all() as $error)
                                    <li style="color: red;">{{$error}}</li>
                                        @endforeach
                                    </ul>   
                                @endif

                                @if ($message = Session::get('success'))
                                    <div class="alert alert-success">
                                        <p style="color: blue;">{{ $message }}</p>
                                    </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
              </div>
        </div>
    </div>
</div>
@endsection