<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="{{asset('css/app.css')}}">
    <script src="{{asset('js/app.js')}}"></script>
    <title>Login</title>
</head>
<body>
    <header>
        <div class="d-flex justify-content-center mt-3">
            <h4 class="m-1 font-weight-bold" style="font-size: 36px"><a href='{{url('/')}}'>ReadandWArite</a></h4>
                <form method="GET" action="{{url('homePage')}}" class="search-form">
                    <input class="col-8" style="width:400px;" type="text" placeholder="Search" name="search" value="{{Request::input('search')}}">
                    <input type="submit" class="btn btn-primary m-2"value="Search">
                </form>
            <a class="btn btn-primary m-2 ml-5" href="{{url('/login')}}">Login</a>
            <a class="btn btn-primary m-2" href="{{url('/register')}}">Register</a>
        </div>
    </header>
    <br>
    <div class="bg-info">
        <br><br>
        <div class="container bg-light card-header my-2">
            <h2 class="m-2">Login</h2>
            <hr>
        <form method="POST" action="{{url('/login')}}" class="text-center">
            {{ csrf_field() }}
                <div>
                    <label for="email" class="col-2 ">Email Address</label>  
                    <input type="email" class="col-3" id="email" name="email" class="form-control @error('email') is-invalid @enderror" value="{{old('email')}}" required>
                </div>
                <br>
                <div>
                    <label for="password" class="col-2">Password</label> 
                    <input type="password" class="col-3" name="password" class="form-control @error('password') is-invalid @enderror" value="{{old('password')}}" required>
                </div>
                <br>
                <div>
                    <label>
                        <input type="checkbox" name="remember"> 
                        Remember me
                    </label>
                </div>
                @if ($notification = Session::get('error'))
                <div class="alert alert-danger alert-block">
                    <strong>{{ $notification }}</strong>
                    </div>
                @endif
                <input type="submit" value="login">
            </form>
            <br><br><br>
        </div>
        <div class="d-flex justify-content-center my-5">
            <img src="images/book_timeline.png" alt="Books" class="img-fluid w-50">
        </div>
    </div>
</body>
</html>