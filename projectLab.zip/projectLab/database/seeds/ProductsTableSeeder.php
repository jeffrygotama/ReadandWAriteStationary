<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProductsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('products')->insert([
            ['name'=>'Pen - Zebra SARASA Clip 0.5mm ',
            'product_types_id'=>1,
            'stock'=> 25,
            'price'=> 16000,
            'description'=>'Zebra SARASA Clip 0.5mm with black color.',
            'image'=>'sarasa.jpg'],

            ['name'=>'Staedtler Mars Lumograph Black Pencil - 8B',
            'product_types_id'=> 2,
            'stock'=> 20,
            'price'=> 8500,
            'description'=>'Mars Lumograph black 100B Grade : 8B. The Mars Lumograph Black contains a high proportion of Carbon which gives a deep, matt, jet black lines.',
            'image'=>'staedtler_pencil.jpg'],

            ['name'=>'Rulers 15 cm',
            'product_types_id'=> 4,
            'stock'=> 100,
            'price'=> 5000,
            'description'=>'rulers with 15 cm long',
            'image'=>'Ruler_15_cm.jpg'],

            ['name'=>'Cover Books',
            'product_types_id'=> 3,
            'stock'=> 100,
            'price'=> 1000,
            'description'=>'Cover books to protect your books from dust and water',
            'image'=>'footer-books.jpg'],

            ['name'=>'Oxford English Mini Dictionary',
            'product_type_id'=>'3',
            'stocks'=>'3',
            'price'=>'123000',
            'description'=>'The latest edition of this small dictionary offers the most accurate and up-to-date coverage of essential, 
            everyday vocabulary with over 90,000 words, phrases, and definitions based on evidence from the Oxford English Corpus, a unique databank comprising hundreds of millions of words of English. 
            Definitions are easy to understand, given in a clear, simple style, and avoiding technical language.',
            'image'=>'oxford_mini_dictionary.jpg'],

            ['name'=>'Cambridge Advanced Learners Dictionary Fourth Edition',
            'product_type_id'=>'3',
            'stocks'=>'2',
            'price'=>'160000',
            'description'=>'A fully updated edition of the best-selling Cambridge Advanced Learners Dictionary.',
            'image'=>'cambridge_dictionary.jpg'],

            ['name'=>
            'Faber-Castell Stylus Pen Vernate II Ocean Blue Barrel',
            'product_type_id'=>'1',
            'stocks'=>'8',
            'price'=>'31050',
            'description'=>'Stylus Pen 2 in 1, usable for all brands of smartphone with 0.7mm ink thickness.',
            'images'=>'faber_stylus_pen.jfif']
        ]);
    }
}
