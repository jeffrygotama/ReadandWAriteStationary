<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
            'username' => 'adrian',
            'email' => 'adrian@gmail.com',
           'password' => bcrypt('adrian123'),
            'roles_id' => 1,
        ]);

        DB::table('users')->insert([
            'username' => 'renaldy',
            'email' => 'renaldy@gmail.com',
           'password' => bcrypt('reinaldy123'),
            'roles_id' => 1,
        ]);

        DB::table('users')->insert([
            'username' => 'roy',
            'email' => 'roy@gmail.com',
           'password' => bcrypt('roy123'),
            'roles_id' => 2,
        ]);

        DB::table('users')->insert([
            'username' => 'stanley',
            'email' => 'stanley@gmail.com',
           'password' => bcrypt('stanley123'),
            'roles_id' => 2,
        ]);
    }
}
