<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProductTypesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('product_types')->insert([
            ['name'=>'Pen',
            'image'=>'Pen.jpg'],

            ['name'=>'Pencil',
            'image'=>'pencil_product_type.jpg'],
            
            ['name'=>'Book',
            'image'=>'books.jpg'],
            
            ['name'=>'Rulers',
            'image'=>'ruler_shape.jpg'],
        ]);
    }
}
