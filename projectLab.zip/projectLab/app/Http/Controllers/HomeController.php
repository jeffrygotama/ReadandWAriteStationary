<?php

namespace App\Http\Controllers;

use App\Product;
use App\ProductType;
use App\Role;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{   
    public function mainProduct(){
        $auth = Auth::check();
        $products = DB::select('select DISTINCT * from product_types limit 4');
        // $products = ProductType::distinct()->select('* limit 4');
        // $products = DB::table('product_types')->distinct()->select('limit 4 *');

        return view('welcome',['products'=>$products],['auth'=>$auth]);
    }

    public function searchByType($product_type_id){
        $auth = Auth::check();
        $product_types = Product::where('product_types_id',"$product_type_id")
                            ->paginate(6);
        $need = [
            'products'=>$product_types,
            'authConfirm'=>$auth,
            'roles'=>Role::all(),
        ];
        return view('homePage',['need'=>$need]);
    }

    public function search(Request $request){
        $auth = Auth::check();
        $search = $request->input(('search'));
        $roles_name = Role::all();
        if($search != null){
            $products = Product::where('name', 'like', "%$search%")
                        ->paginate(6);
        }else{
            $products = Product::paginate(6);
        }
        $need = [
            'roles'=>$roles_name,
            'products'=>$products,
            'authConfirm'=>$auth,
        ];
        return view('/homePage',['need'=>$need]);
    }
}
