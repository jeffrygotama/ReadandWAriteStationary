<?php

namespace App\Http\Controllers;

use App\Cart;
use Illuminate\Support\Facades\Validator;
use App\Product;
use App\ProductType;
use App\Role;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
// use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;

class productController extends Controller
{

    public function detail($id){
        $auth = Auth::check();
        $roles_name = Role::all();
        $products = Product::where('id',"$id")
                    ->first();

        $need = [
            'roles'=>$roles_name,
            'authConfirm'=>$auth,
        ];
        return view('detail',['need'=>$need],['product'=>$products]);
    }

    public function edit($id){
        $need = [
            'roles'=>Role::all(),
            'authConfirm'=>Auth::check(),
        ];
        $product = Product::where('id',"$id")
                    ->first();
        return view('edit',['need'=>$need],['product'=>$product]);
    }

    public function update($id, Request $request){
        $validatorss = Validator::make($request->all(), [
            'name'=>'required|min:5|unique:products',
            'stock'=>'required|numeric|min:1',
            'price'=>'required|numeric|min:5001',
            'description'=>'required|min:10',
        ]);
        if ($validatorss->fails()) {
            return redirect('/edit'.$id)
                ->withErrors($validatorss)
                ->withInput();
        }

        $input = $request->all();
        $productss = Product::find($id)->update([
            'name'=>$input['name'],
            'stock'=>$input['stock'],
            'price'=>$input['price'],
            'description'=>$input['description'],

        ]);
     
        return redirect('/edit'.$id)->with('success', 'data updated successfully.');
    }

    public function delete($id){
        $product = Product::where('id',"$id")->first();
        $file = public_path('images/'.$product->image);
        $img = File::delete($file);
        Product::destroy($id);
        $need = [
            'roles'=>Role::all(),
            'authConfirm'=>Auth::check(),
            'products'=>Product::paginate(6),
        ];


        return redirect('/homePage')->with('need',$need);
    }

    public function add(){
        $need = [
            'roles'=>Role::all(),
            'authConfirm'=>Auth::check(),
            'products'=>Product::paginate(6),
        ];
        $product_typess = ProductType::all();
        return view('/add', ['need'=>$need], ['product_typess'=>$product_typess]);
    }

    public function addData(Request $request){
        $validatorss = Validator::make($request->all(),[
            'name'=>'required|min:5|unique:products',
            'stationary_type'=>'required',
            'stock'=>'required|numeric|min:1',
            'price'=>'required|numeric|min:5001',
            'file_image'=>'required|image|max:2000',
            'description'=>'required|min:10',
        ]);

        if($validatorss->fails()){
            return redirect('/add')
                ->withErrors($validatorss)
                ->withInput();
        }

        $input = $request->all();

        $file = $request->file('file_image');
        $basename = $file->getClientOriginalName();
        // $file->storeAs('public/images/', $basename);
        $file->move(public_path('images'), $basename);

        $products = Product::create([
            'name' => $input['name'],
            'product_types_id'=> $input['stationary_type'],
            'stock' => $input['stock'],
            'price' => $input['price'],
            'description' => $input['description'],
            'image'=>$basename,
        ]);
     
        return redirect('/add')->with('success', 'data created successfully.');
    }


    public function erganzToCartss($id, Request $request){
        $prod = Product::where('id',"$id")->first();

        $validatorss = Validator::make($request->all(),[
            'quantity'=>"numeric|min:1|max:$prod->stock",
        ]);
            
        if($validatorss->fails()){
                return redirect('/detail'.$id)
                ->withErrors($validatorss)
                ->withInput();
        }

        $input = $request->all();
        // $prod->update([
        //     'stock'=>$prod->stock - $input['quantity'],
        // ]);

        $total = $input['quantity'] * $prod->price;
        $user_id = auth()->user();

        $meet = false;
        if(sizeof(Cart::all()) >= 1){
            $cart = Cart::all();
            foreach ($cart as $item) {
                if($item->products_id == $prod->id && $item->users_id == $user_id->id){
                    $item->update([
                        $item->quantity = $item->quantity + $input['quantity'],
                        $item->total = $item->quantity * $prod->price, 
                    ]);
                    $meet = true;
                }
            }
        }

        if($meet == false){
            $carts = Cart::create([
                'users_id'=>$user_id->id,
                'products_id'=>$id,
                'quantity'=> $input['quantity'],
                'total'=>$total,
            ]);
        }

        return redirect('/detail'.$id)->with('success', 'product has been added to cart');


    }


}
