<?php

namespace App\Http\Controllers;

use App\Cart;
use App\DetailTransaction;
use App\Product;
use App\Role;
use App\Transaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class CartController extends Controller
{
    public function shopping_cart($id){
        $allCarts = Cart::where('users_id',"$id")
                ->get();
        $need = [
            'roles'=>Role::all(),
            'authConfirm'=>Auth::check(),
        ];
        return view('/shopping_cart',['need'=>$need],['allCarts'=>$allCarts]);
    }

    public function cartEditPage($id){
        $need = [
            'roles'=>Role::all(),
            'authConfirm'=>Auth::check(),
        ];

        $prodInCart = Cart::where('id',"$id")->first();

        return view('/update_cart',['need'=>$need],['prodCart'=>$prodInCart]);

    }

    public function bearbeiten_cart($id, Request $request){
        $cart_record = Cart::where('id',"$id")->first();
        $prod = Product::where('id',"$cart_record->products_id")->first();

        $validatorss = Validator::make($request->all(),[
            'quantity'=>"numeric|min:1|max:$prod->stock",
        ]);
            
        if($validatorss->fails()){
                return redirect('/update_cart'.$id)
                ->withErrors($validatorss)
                ->withInput();
        }

        $input = $request->all();
        $cart_record->update([
            'quantity'=>$input['quantity'],
            'total'=>$input['quantity'] * $prod->price,
        ]);

        return redirect('/update_cart'.$id)->with('success', 'Cart has been updated');
    }


    public function lösen($id){
        Cart::destroy($id);
        $user_record = auth()->user();
        return redirect('/shopping_cart'.$user_record->id)->with('success', 'product has been removed from cart');
    }

    public function transaction_add($id){
        $cart = Cart::where('users_id',"$id")
                ->OrderBy('created_at', 'asc')
                ->get();
        
        $total = 0;
        foreach ($cart as $item) {
            $total = $total + $item->total;
        }
        $transaction = Transaction::create([
            'users_id'=>$id,
            'total'=>$total,
        ]);
        foreach ($cart as $item) {
            DetailTransaction::create([
                'transactions_id'=> $transaction->id,
                'products_id'=>$item->products_id,
                'quantity'=>$item->quantity,
                'subtotal'=>$item->total,
            ]);
            $product = Product::where('id',"$item->products_id")->first();
            Product::find($product->id)->update([
                'stock'=> $product->stock - $item->quantity,
        
            ]);
        }
        Cart::where('users_id', "$id")->delete();
        // DB::table('carts')->delete();

        return redirect('/shopping_cart'.$id)->with('success_add_transaction', 'all product in cart has been checked out');
    }
}
