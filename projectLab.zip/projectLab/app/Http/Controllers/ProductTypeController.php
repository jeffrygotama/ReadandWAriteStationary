<?php

namespace App\Http\Controllers;

use App\Product;
use App\ProductType;
use App\Role;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;

class ProductTypeController extends Controller
{
    public function addTypePage(){
        $need = [
            'roles'=>Role::all(),
            'authConfirm'=>Auth::check(),
            'products'=>Product::paginate(6),
        ];
        $productTypes = ProductType::all();

        return view('addProductTypes',['need'=>$need],['productTypes'=>$productTypes]);
    }

    public function increaseProductType(Request $request){
        $validatorss = Validator::make($request->all(),[
            'name'=>'required|unique:product_types',
            'file_image'=>'required|image|max:2000',
        ]);
        if($validatorss->fails()){
            return redirect('/addProductTypes')
                ->withErrors($validatorss)
                ->withInput();
        }

        $input = $request->all();

        $file = $request->file('file_image');
        $basename = $file->getClientOriginalName();
        // $file->storeAs('public/storage/images/', $basename);
        $file->move(public_path('images'), $basename);

        ProductType::create([
            'name'=>$input['name'],
            'image'=>$basename,
        ]);

        return redirect('/addProductTypes')->with('success', 'data created successfully.');
    }

    public function editPage(){
        $need = [
            'roles'=>Role::all(),
            'authConfirm'=>Auth::check(),
            'products'=>Product::paginate(6),
        ];
        $productTypes = ProductType::all();
        return view('statTypes',['need'=>$need],['productTypes'=>$productTypes]);
    }

    public function updates($id, Request $request){
        $validatorss = Validator::make($request->all(),[
            'name'=>'required|unique:product_types',
        ]);
        if($validatorss->fails()){
            return redirect('/statTypes')
                ->withErrors($validatorss)
                ->withInput();
        }

        $input = $request->all();
        $product_type = ProductType::find($id)->update([
            'name' => $input['name'],
        ]);
        return redirect('/statTypes')->with('success', 'data updated successfully.');

    }

    public function deleteProdTypes($id){
        // ProductType::destroy($id);
        // $stat_type = ProductType::find($id);
        // $stat_type->delete();

        $productType = ProductType::where('id',"$id")->first();
        $file = public_path('images/'.$productType->image);
        $img = File::delete($file);


        ProductType::find($id)->delete();
        
        $need = [
            'roles'=>Role::all(),
            'authConfirm'=>Auth::check(),
            'products'=>Product::paginate(6),
        ];

        return redirect('/statTypes')->with('success', 'data deleted successfully.');
    }
}
