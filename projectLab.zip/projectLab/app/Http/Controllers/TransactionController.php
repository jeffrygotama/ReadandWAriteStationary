<?php

namespace App\Http\Controllers;

use App\DetailTransaction;
use App\Role;
use App\Transaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TransactionController extends Controller
{
    public function transaction_page($id){
        $need = [
            'roles'=>Role::all(),
            'authConfirm'=>Auth::check(),
        ];
        // 'transaction'=> Transaction::where('users_id',"$id")->OrderBy('created_at','asc')->get(),
        $transactions = Transaction::where('users_id',"$id")->OrderBy('created_at','asc')->get();
        // $detail = DetailTransaction::where('transactions_id',"$transactions->id")->get();

        return view('/transaction_history',['need'=>$need], ['transactions'=>$transactions]);
    }


}
