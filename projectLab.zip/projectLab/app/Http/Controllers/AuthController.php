<?php

namespace App\Http\Controllers;

use App\Product;
use App\Role;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Contracts\Routing\ResponseFactory;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;

class AuthController extends Controller
{
    public function loginPage(){
        return view('/login');
    }

    public function login(Request $request){
        $userInfo = $request->only('roles_id','email','password');
        $remember_me = $request->has('remember') ? true : false; 
        if(Auth::attempt($userInfo)){
            $roles_name = Role::all();
            $products = Product::paginate(6);
            $auth = Auth::check();
            $need = [
                'roles'=>$roles_name,
                'products'=>$products,
                'authConfirm'=> $auth,
            ];
            $remember_me = $request->has('remember') ? true : false; 
            if ($remember_me == true) {
                $email = $request->email;
                $password = $request->password;
                $minutes = 120;
                return response()->view('/homePage',['need'=>$need])->withCookie(cookie($email, $password, $minutes));
            }
            return redirect('/homePage')->with('need',$need);

        }else{
            
            // return redirect('login')->withSuccess('Mail Address or Password are Incorrect. Please Try Again');
            return redirect('login')->with('error','Mail Address or Password are Incorrect. Please Try Again');
        }
    }

    public function registerPage(){
        return view('register');
    }
    
    public function register(Request $request){
        $validatorss = Validator::make($request->all(),[
            'name'=>'required|min:5',
            'email'=>'required|email|unique:users',
            'password'=>['required','string','alpha_num','min:6','regex:/[a-z]/','regex:/[0-9]/'],
            'confirm_password'=>'required|same:password'
        ]);
        if($validatorss->fails()){
            return redirect('register')
                ->withErrors($validatorss)
                ->withInput();
        }
        $input = $request->all();
        $user = User::create([
            'username' => $input['name'],
            'email' => $input['email'],
            'password' => bcrypt($input['password']),
            'roles_id'=> 2,
        ]);
     
        return redirect('register')->with('success', 'User created successfully.');
    }

    public function logout(){
        Auth::logout();
        return redirect('/');
    }

}
