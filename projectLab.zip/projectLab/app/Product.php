<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    //
    protected $table = 'products';
    public function product_type(){
        return $this->belongsTo('App\ProductType', 'product_types_id');
    }

    protected $fillable = [
        'name','product_types_id', 'stock', 'price','description','image'
    ];

    public function cart(){
        return $this->hasMany('App\Cart', 'carts_id');
    }
}
