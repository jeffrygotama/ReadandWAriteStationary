<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DetailTransaction extends Model
{

    public function transaction(){
        return $this->belongsTo(Transaction::class, 'transactions_id');
    }

    public function product(){
        return $this->belongsTo(Product::class, 'products_id');
    }

    protected $fillable = [
        'transactions_id','products_id', 'quantity', 'subtotal',
    ];
}
