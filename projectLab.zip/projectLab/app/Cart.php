<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cart extends Model
{
    public function User(){
        return $this->belongsTo('\App\User','users_id');
    }

    public function products()
    {
        return $this->belongsTo('App\Product', 'products_id');
    }

    protected $fillable = [
        'users_id','products_id','quantity','total'
    ];
}
