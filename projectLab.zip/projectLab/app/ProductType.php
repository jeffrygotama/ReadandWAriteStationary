<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductType extends Model
{
    public function Products(){
        $this->hasMany('App\Product', 'products_id');
    }
    
    protected $fillable = [
        'name','image'
    ];
    protected $table = 'product_types';
}
