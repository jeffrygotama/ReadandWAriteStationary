<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Transaction extends Model{
    public function detailTransaction(){
        return $this->hasMany(DetailTransaction::class, 'transactions_id');
    }

    public function users(){
        return $this->belongsTo(User::class, 'users_id');
    }

    protected $fillable = [
        'users_id','total',
    ];
}
